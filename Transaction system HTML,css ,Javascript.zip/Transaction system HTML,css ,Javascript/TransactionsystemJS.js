
CustomerAddButton.addEventListener('click',addCustomer);
function Customer(ID,FirstName,Surname){
    this.ID = ID;
    this.FirstName = FirstName;
    this.Surname = Surname;
}
var customer =[];

function addCustomer(){
    var CustomerName = document.getElementById("fname").value;
    var CustomerSurname = document.getElementById("lname").value;
    var date = new Date();
    var CustomerId = date.getTime();
    var newCustomer = new Customer(CustomerId,CustomerName,CustomerSurname);
     customer.push(newCustomer);
    CustomerTable();
    createDropdown();
}

function CustomerTable(){
    var k = "<tbody>";
    for(i = 0; i < customer.length; i++){
        k+='<tr id="customerRow">';
        k+='<td>'+customer[i].FirstName+'</td>';
        k+='<td>'+customer[i].Surname+'</td>';
        k+='</tr>';
    }
     k+="</tbody>";
     document.getElementById('CustomerTableData').innerHTML = k;
}
ProductAddButton.addEventListener('click',addProduct);



function Products(ProductID,Name,Price){
          this.ProductID = ProductID;
          this.Name =Name;
          this.Price =Price;
}
        
      
    
var products =[];

function addProduct(){
    var ProductName = document.getElementById("Pname").value;
    var ProductUnitprice = document.getElementById("productprice").value;
    var date = new Date();
    var ProductId = date.getTime();
    var NewProduct = new Products(ProductId,ProductName,ProductUnitprice);
    products.push(NewProduct);
    ProductsTable();
    createProductDropdown();
    
}

function createDropdown(){
    var dropdown = '<select>';
    for(i = 0; i < customer.length; i++){
        dropdown+='<option>'+customer[i].FirstName+'</option>';
    }
    dropdown+='</select>'    
    document.getElementById('dropdown-stuff').innerHTML = dropdown;
}
function createProductDropdown(){
    var dropdown = '<select>';
    for(i = 0; i < products.length; i++){
        dropdown+='<option>'+products[i].Name+'</option>';
    }
    dropdown+='</select>'    
    document.getElementById('Productslist').innerHTML = dropdown;
}

function ProductsTable() 
{
    var p = "<tbody>";
    for(m = 0; m < products.length; m++){
       p +='<tr id="Productrow">';
        p+='<td>'+products[m].Name+'</td>';
        p+='<td>'+products[m].Price+'</td>';
        p+='</tr>';
    }
     p+="</tbody>";
     document.getElementById('Producttabledata').innerHTML = p;   
  }

  function Transaction(transcustomerName,transprodname,transunitprice,transquantity){
    this.transcustomerName = transcustomerName;
    this.transprodname =transprodname;
    this.transunitprice = transunitprice;
    this.transquantity=transquantity;          
}

var transactions = [];

function CreateTransactionTable(){
    var o = "<tbody>";
    for(m = 0; m < transactions.length; m++){
       o +='<tr id="Productrow">';
       o +='<td>'+transactions[m].transcustomerName+'</td>';
        o+='<td>'+transactions[m].transprodname+'</td>';
         o+='<td>'+transactions[m].transunitprice+'</td>'
        o+='<td>'+transactions[m].transquantity+'</td>'

        o+='</tr>';
    }
     o+="</tbody>";
     document.getElementById('TransactionTabledata').innerHTML = o;  
}
TransactionAddButton.addEventListener('click',AddTransaction);
function AddTransaction(){
    var CustomerName = document.getElementById("dropdown-stuff").value;
    var TransProduct = document.getElementById("Productslist").value;
    var TransQuantity = document.getElementById("QuantityofProducts").value;
    var TransUnitPrice = 0;
    for(var i =0; i < products.length;i++){
        if(TransProduct == products[i].Name){
            TransUnitPrice = products[i].Price;
        }
    }
     var NewTransaction = new Transaction(CustomerName,TransProduct, TransQuantity, TransUnitPrice);
     transactions.push(NewTransaction);
     CreateTransactionTable();

}

